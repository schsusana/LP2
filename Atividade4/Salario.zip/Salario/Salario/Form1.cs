﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Salario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lblDados_Click(object sender, EventArgs e)
        {

        }

        public void Form1_Load(object sender, EventArgs e)
        {
            

        }

        private void txtbxNomeFunc_TextChanged(object sender, EventArgs e)
        {
            if ((txtbxNomeFunc.Text == "") || (txtbxNomeFunc.Text.Length < 4));
            MessageBox.Show("Nome inválido");
        }

        private void mskbxSalarioBruto_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
           
        }

        private void btnVerificDesconto_Click(object sender, EventArgs e)
        {
         
            double salarioFamilia = 0;
            double salarioBruto = 0;
            double numFilhos = 0;
            double descontoIRPF = 0;
            double descontoINSS = 0;
            double salarioLiquido = 0;

            if (double.TryParse(mskbxSalarioBruto.Text, out salarioBruto))
              if  (double.TryParse(mskbxDescIRPF.Text, out descontoIRPF))
               if (double.TryParse(mskbxDescINSS.Text, out descontoINSS))
                if (double.TryParse(mskbxSalarioBruto.Text, out salarioBruto))
                if (double.TryParse(mskbxSalarioLiquido.Text, out salarioLiquido))

            if (salarioBruto <= 800.47)
            {
                mskbxAliqINSS.Text = "7,65";
                descontoINSS = 0.0765 * salarioBruto;
            }
             else if (salarioBruto < 1050)
            {
                mskbxAliqINSS.Text = "8,65";
                descontoINSS = 0.0865 * salarioBruto;

            }
            else if (salarioBruto < 1400.77)
            {
                mskbxAliqINSS.Text = "9";
                descontoINSS = 0.09 * salarioBruto;
            }
             if (salarioBruto<= 1257.12);
            {
                mskbxAliqIRPF.Text = "0";
                descontoIRPF = 0;
            }
            if (salarioBruto <= 2512.08)
            {
                mskbxAliqIRPF.Text = "15";
                descontoIRPF = 0.15 * salarioBruto;
            }
            if (salarioBruto > 2512.08)
            {
                mskbxAliqIRPF.Text = "27.5";
                descontoIRPF = 0.275 * salarioBruto;
            }

             
            if   (double.TryParse(mskbxNumFilhos.Text, out numFilhos))
             if (salarioBruto <= 435.52) ;
            {
                salarioFamilia = 22.33 * numFilhos;
            }
           if (salarioBruto <=654.61) ;
            {
                salarioFamilia = 15.74 * numFilhos;
            }
           if (salarioBruto > 654.61) ;
            {
                salarioFamilia = 0;
            }

            salarioLiquido = salarioBruto - descontoINSS - descontoIRPF + salarioFamilia;

        }
    }
}
