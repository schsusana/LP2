﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        string verifica = "^[a-zA-Z]";
        double LadoA, LadoB, LadoC;
      

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(textBox1.Text, verifica))

               MessageBox.Show("Digite um valor numérico maior que 0");
                 }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(textBox2.Text, verifica))

                MessageBox.Show("Digite um valor numérico maior que 0");
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (Regex.IsMatch(textBox3.Text, verifica))

                MessageBox.Show("Digite um valor numérico maior que 0");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double.TryParse(textBox1.Text, out LadoA);
            double.TryParse(textBox2.Text, out LadoB);
            double.TryParse(textBox3.Text, out LadoC);

            
                if (LadoA == LadoB && LadoB == LadoC);
            {
                MessageBox.Show("Triângulo equilátero");
            }
            
                if (LadoA == LadoB || LadoB == LadoC || LadoC == LadoA);
            {
                MessageBox.Show("Triângulo isosceles");
            }

               if (LadoA != LadoB && LadoB != LadoC && LadoC != LadoA);
            {
                MessageBox.Show("Triângulo escaleno");
            }
        }
    }
}
