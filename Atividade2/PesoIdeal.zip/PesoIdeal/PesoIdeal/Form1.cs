﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PesoIdeal
{
    public partial class Form1 : Form
    {
        double Altura, Peso, PesoIdeal;

        private void MaskedTextBoxP_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            
        }

        private void RadioButtonF_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RadioButtonM_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void ButtonCalc_Click(object sender, EventArgs e)
        {
            double.TryParse(MaskedTextBoxP.Text, out Peso);
            double.TryParse(MaskedTextBoxA.Text, out Altura);

            if (RadioButtonF.Checked)
            PesoIdeal = (62.1 * Altura) - 44.7;

            if (RadioButtonM.Checked)
            PesoIdeal = (72.7 * Altura) - 58;

            if (PesoIdeal == Peso)
                {
                MessageBox.Show("Você está no peso ideal");
                }
            if (PesoIdeal > Peso)
            {
                MessageBox.Show("Coma bastante massas e doces");
            }
            if (PesoIdeal < Peso)
            {
                MessageBox.Show("Regime obrigatório já");
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void MaskedTextBoxA_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            
        }
    }
}
