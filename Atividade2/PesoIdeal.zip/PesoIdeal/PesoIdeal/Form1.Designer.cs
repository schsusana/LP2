﻿
namespace PesoIdeal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.RadioButtonM = new System.Windows.Forms.RadioButton();
            this.RadioButtonF = new System.Windows.Forms.RadioButton();
            this.ButtonCalc = new System.Windows.Forms.Button();
            this.MaskedTextBoxA = new System.Windows.Forms.MaskedTextBox();
            this.MaskedTextBoxP = new System.Windows.Forms.MaskedTextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.RadioButtonM);
            this.groupBox1.Controls.Add(this.RadioButtonF);
            this.groupBox1.Location = new System.Drawing.Point(301, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(151, 123);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            // 
            // RadioButtonM
            // 
            this.RadioButtonM.AutoSize = true;
            this.RadioButtonM.Location = new System.Drawing.Point(24, 68);
            this.RadioButtonM.Name = "RadioButtonM";
            this.RadioButtonM.Size = new System.Drawing.Size(73, 17);
            this.RadioButtonM.TabIndex = 1;
            this.RadioButtonM.TabStop = true;
            this.RadioButtonM.Text = "Masculino";
            this.RadioButtonM.UseVisualStyleBackColor = true;
            this.RadioButtonM.CheckedChanged += new System.EventHandler(this.RadioButtonM_CheckedChanged);
            // 
            // RadioButtonF
            // 
            this.RadioButtonF.AutoSize = true;
            this.RadioButtonF.Location = new System.Drawing.Point(24, 35);
            this.RadioButtonF.Name = "RadioButtonF";
            this.RadioButtonF.Size = new System.Drawing.Size(67, 17);
            this.RadioButtonF.TabIndex = 0;
            this.RadioButtonF.TabStop = true;
            this.RadioButtonF.Text = "Feminino";
            this.RadioButtonF.UseVisualStyleBackColor = true;
            this.RadioButtonF.CheckedChanged += new System.EventHandler(this.RadioButtonF_CheckedChanged);
            // 
            // ButtonCalc
            // 
            this.ButtonCalc.Location = new System.Drawing.Point(331, 247);
            this.ButtonCalc.Name = "ButtonCalc";
            this.ButtonCalc.Size = new System.Drawing.Size(75, 23);
            this.ButtonCalc.TabIndex = 1;
            this.ButtonCalc.Text = "Calcular";
            this.ButtonCalc.UseVisualStyleBackColor = true;
            this.ButtonCalc.Click += new System.EventHandler(this.ButtonCalc_Click);
            // 
            // MaskedTextBoxA
            // 
            this.MaskedTextBoxA.Location = new System.Drawing.Point(352, 170);
            this.MaskedTextBoxA.Mask = "0.00";
            this.MaskedTextBoxA.Name = "MaskedTextBoxA";
            this.MaskedTextBoxA.Size = new System.Drawing.Size(100, 20);
            this.MaskedTextBoxA.TabIndex = 2;
            this.MaskedTextBoxA.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBoxA_MaskInputRejected);
            // 
            // MaskedTextBoxP
            // 
            this.MaskedTextBoxP.Location = new System.Drawing.Point(351, 204);
            this.MaskedTextBoxP.Mask = "00.0";
            this.MaskedTextBoxP.Name = "MaskedTextBoxP";
            this.MaskedTextBoxP.Size = new System.Drawing.Size(100, 20);
            this.MaskedTextBoxP.TabIndex = 3;
            this.MaskedTextBoxP.MaskInputRejected += new System.Windows.Forms.MaskInputRejectedEventHandler(this.MaskedTextBoxP_MaskInputRejected);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(301, 177);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Altura";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(301, 207);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Peso";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.MaskedTextBoxP);
            this.Controls.Add(this.MaskedTextBoxA);
            this.Controls.Add(this.ButtonCalc);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton RadioButtonM;
        private System.Windows.Forms.RadioButton RadioButtonF;
        private System.Windows.Forms.Button ButtonCalc;
        private System.Windows.Forms.MaskedTextBox MaskedTextBoxA;
        private System.Windows.Forms.MaskedTextBox MaskedTextBoxP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

